import pandas as pd
import sqlite3
import json
from flask import Flask, jsonify
from flask_socketio import SocketIO

app = Flask(__name__)
socketio = SocketIO(app)

# Read sqlite query results into a pandas DataFrame
with sqlite3.connect("travel.sqlite") as con:
    aircrafts_data = pd.read_sql_query("SELECT * from aircrafts_data", con)
    airports_data = pd.read_sql_query("SELECT * from airports_data", con)
    boarding_passes = pd.read_sql_query("SELECT * from boarding_passes", con)
    flights = pd.read_sql_query("SELECT * from flights", con)
    seats = pd.read_sql_query("SELECT * from seats", con)
    ticket_flights = pd.read_sql_query("SELECT * from ticket_flights", con)
    tickets = pd.read_sql_query("SELECT * from tickets", con)

# Clean dictionary from data
aircrafts_data['model'] = aircrafts_data['model'].apply(lambda x: json.loads(x).get('en') if isinstance(x, str) else x)
airports_data['airport_name'] = airports_data['airport_name'].apply(lambda x: json.loads(x).get('en') if (isinstance(x, str) and x.strip().startswith('{')) else x)
airports_data['city'] = airports_data['city'].apply(lambda x: json.loads(x).get('en') if (isinstance(x, str) and x.strip().startswith('{')) else x)
# Handle the missing with expect values 
flights['actual_departure'] = flights.apply(lambda row: row['scheduled_departure'] if row['actual_departure'] == '\\N' else row['actual_departure'], axis=1)
flights['actual_arrival'] = flights.apply(lambda row: row['scheduled_arrival'] if row['actual_arrival'] == '\\N' else row['actual_arrival'], axis=1)

# JSON data for different types
aircrafts_json = aircrafts_data.to_json(orient='records', indent=2)
airports_json = airports_data.to_json(orient='records', indent=2)
boarding_passes_json = boarding_passes.to_json(orient='records', indent=2)
flights_json = flights.to_json(orient='records', indent=2)
seats_json = seats.to_json(orient='records', indent=2)
ticket_flights_json = ticket_flights.to_json(orient='records', indent=2)
tickets_json = tickets.to_json(orient='records', indent=2)

@app.route('/api/aircrafts')
def get_aircrafts_api():
    return jsonify(aircrafts_data.to_dict(orient='records'))

@app.route('/api/airports')
def get_airports_api():
    return jsonify(airports_data.to_dict(orient='records'))

@app.route('/api/boarding_passes')
def get_boarding_passes_api():
    return jsonify(boarding_passes.to_dict(orient='records'))

@app.route('/api/flights')
def get_flights_api():
    return jsonify(flights.to_dict(orient='records'))

@app.route('/api/seats')
def get_seats_api():
    return jsonify(seats.to_dict(orient='records'))

@app.route('/api/ticket_flights')
def get_ticket_flights_api():
    return jsonify(ticket_flights.to_dict(orient='records'))

@app.route('/api/tickets')
def get_tickets_api():
    return jsonify(tickets.to_dict(orient='records'))

if __name__ == '__main__':
    socketio.run(app, debug=True, port=5000, allow_unsafe_werkzeug=True)
